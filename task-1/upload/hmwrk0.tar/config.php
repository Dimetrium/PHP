<?php
define('HOST', 'localhost');
define('PASSWORD', '12345');
define('USER', 'root');
define('RCOLOR', '1');
?>
